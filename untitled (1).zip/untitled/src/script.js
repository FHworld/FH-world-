function likePost() {
    alert("آپ نے پوسٹ کو پسند کیا!");
}

function comment() {
    let userComment = prompt("اپنا تبصرہ لکھیں:");
    if (userComment) {
        alert("آپ کا تبصرہ: " + userComment);
    }
}